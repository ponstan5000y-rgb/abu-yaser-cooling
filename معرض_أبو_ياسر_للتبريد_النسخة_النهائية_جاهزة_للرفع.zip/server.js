const express = require('express');
const path = require('path');
const crypto = require('crypto');
const { Pool } = require('pg');

const app = express();
const PORT = process.env.PORT || 3000;
const DATABASE_URL = process.env.DATABASE_URL;
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD;

if (!DATABASE_URL) {
  console.error('DATABASE_URL is required.');
  process.exit(1);
}
if (!ADMIN_PASSWORD) {
  console.error('ADMIN_PASSWORD is required.');
  process.exit(1);
}

const pool = new Pool({
  connectionString: DATABASE_URL,
  ssl: process.env.NODE_ENV === 'production' ? { rejectUnauthorized: false } : false,
  max: 5,
});

app.use(express.json({ limit: '10mb' }));
app.use(express.static(__dirname));

async function initDb() {
  await pool.query(`
    CREATE TABLE IF NOT EXISTS products (
      id SERIAL PRIMARY KEY,
      name TEXT NOT NULL,
      category TEXT NOT NULL,
      price INTEGER NOT NULL,
      stock INTEGER NOT NULL DEFAULT 0,
      description TEXT DEFAULT '',
      image TEXT DEFAULT '',
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    );
    CREATE TABLE IF NOT EXISTS orders (
      id SERIAL PRIMARY KEY,
      customer_name TEXT NOT NULL,
      phone TEXT NOT NULL,
      address TEXT NOT NULL,
      note TEXT DEFAULT '',
      total INTEGER NOT NULL,
      status TEXT NOT NULL DEFAULT 'new',
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    );
    CREATE TABLE IF NOT EXISTS order_items (
      id SERIAL PRIMARY KEY,
      order_id INTEGER NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
      product_id INTEGER NOT NULL,
      product_name TEXT NOT NULL,
      quantity INTEGER NOT NULL,
      price INTEGER NOT NULL
    );
  `);

  const { rows } = await pool.query('SELECT COUNT(*)::int AS n FROM products');
  if (rows[0].n === 0) {
    const seed = [
      ['مكيف سبليت 1 طن','مكيفات',650000,5,'تبريد منزلي',''],
      ['مكيف سبليت 1.5 طن','مكيفات',850000,4,'تبريد قوي',''],
      ['مكيف سبليت 2 طن','مكيفات',1100000,3,'للمساحات الأكبر',''],
      ['ثلاجة منزلية','ثلاجات',900000,3,'استخدام منزلي',''],
      ['فريزر أفقي','فريزرات',700000,3,'حفظ وتجميد',''],
      ['قطع غيار تبريد','قطع غيار',25000,20,'حسب النوع',''],
    ];
    for (const p of seed) {
      await pool.query(
        'INSERT INTO products(name,category,price,stock,description,image) VALUES($1,$2,$3,$4,$5,$6)',
        p
      );
    }
  }
}

function adminGuard(req, res, next) {
  const supplied = req.get('x-admin-password') || '';
  const a = Buffer.from(supplied);
  const b = Buffer.from(ADMIN_PASSWORD);
  if (a.length !== b.length || !crypto.timingSafeEqual(a, b)) {
    return res.status(401).json({ error: 'غير مصرح' });
  }
  next();
}

app.get('/api/health', async (req, res) => {
  try {
    await pool.query('SELECT 1');
    res.json({ ok: true, database: 'PostgreSQL' });
  } catch (e) {
    res.status(500).json({ ok: false, error: 'database unavailable' });
  }
});

app.post('/api/admin/login', (req, res) => {
  const supplied = String(req.body?.password || '');
  const a = Buffer.from(supplied);
  const b = Buffer.from(ADMIN_PASSWORD);
  const ok = a.length === b.length && crypto.timingSafeEqual(a, b);
  if (!ok) return res.status(401).json({ ok: false, error: 'كلمة المرور غير صحيحة' });
  res.json({ ok: true });
});

app.get('/api/products', async (req, res) => {
  try {
    const { rows } = await pool.query('SELECT * FROM products ORDER BY id DESC');
    res.json(rows);
  } catch (e) { res.status(500).json({ error: 'تعذر تحميل المنتجات' }); }
});

app.post('/api/products', adminGuard, async (req, res) => {
  try {
    const { name, category, price, stock = 0, description = '', image = '' } = req.body;
    if (!name || !category || !Number(price)) return res.status(400).json({ error: 'بيانات المنتج ناقصة' });
    const { rows } = await pool.query(
      'INSERT INTO products(name,category,price,stock,description,image) VALUES($1,$2,$3,$4,$5,$6) RETURNING *',
      [name, category, Number(price), Number(stock), description, image]
    );
    res.json(rows[0]);
  } catch (e) { res.status(500).json({ error: 'تعذر حفظ المنتج' }); }
});

app.put('/api/products/:id', adminGuard, async (req, res) => {
  try {
    const { name, category, price, stock = 0, description = '', image = '' } = req.body;
    const { rows } = await pool.query(
      'UPDATE products SET name=$1,category=$2,price=$3,stock=$4,description=$5,image=$6 WHERE id=$7 RETURNING *',
      [name, category, Number(price), Number(stock), description, image, Number(req.params.id)]
    );
    if (!rows.length) return res.status(404).json({ error: 'المنتج غير موجود' });
    res.json(rows[0]);
  } catch (e) { res.status(500).json({ error: 'تعذر تعديل المنتج' }); }
});

app.delete('/api/products/:id', adminGuard, async (req, res) => {
  try {
    await pool.query('DELETE FROM products WHERE id=$1', [Number(req.params.id)]);
    res.json({ ok: true });
  } catch (e) { res.status(500).json({ error: 'تعذر حذف المنتج' }); }
});

app.post('/api/orders', async (req, res) => {
  const { customer_name, phone, address, note = '', items = [] } = req.body;
  if (!customer_name || !phone || !address || !items.length) return res.status(400).json({ error: 'بيانات الطلب ناقصة' });

  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    let total = 0;
    const normalized = [];
    for (const item of items) {
      const q = Number(item.quantity);
      const { rows } = await client.query('SELECT * FROM products WHERE id=$1 FOR UPDATE', [Number(item.product_id)]);
      const p = rows[0];
      if (!p || q < 1 || !Number.isInteger(q)) throw new Error('منتج غير صالح');
      if (p.stock < q) throw new Error(`المخزون غير كافٍ للمنتج: ${p.name}`);
      total += p.price * q;
      normalized.push({ p, q });
    }

    const orderResult = await client.query(
      'INSERT INTO orders(customer_name,phone,address,note,total) VALUES($1,$2,$3,$4,$5) RETURNING id,total',
      [customer_name, phone, address, note, total]
    );
    const order = orderResult.rows[0];
    for (const x of normalized) {
      await client.query(
        'INSERT INTO order_items(order_id,product_id,product_name,quantity,price) VALUES($1,$2,$3,$4,$5)',
        [order.id, x.p.id, x.p.name, x.q, x.p.price]
      );
      await client.query('UPDATE products SET stock=stock-$1 WHERE id=$2', [x.q, x.p.id]);
    }
    await client.query('COMMIT');
    res.json({ id: order.id, total: order.total });
  } catch (e) {
    await client.query('ROLLBACK');
    res.status(400).json({ error: e.message || 'تعذر إنشاء الطلب' });
  } finally { client.release(); }
});

app.get('/api/orders', adminGuard, async (req, res) => {
  try {
    const { rows: orders } = await pool.query('SELECT * FROM orders ORDER BY id DESC');
    const { rows: items } = await pool.query('SELECT * FROM order_items ORDER BY id');
    const grouped = new Map();
    for (const i of items) {
      if (!grouped.has(i.order_id)) grouped.set(i.order_id, []);
      grouped.get(i.order_id).push(i);
    }
    res.json(orders.map(o => ({ ...o, items: grouped.get(o.id) || [] })));
  } catch (e) { res.status(500).json({ error: 'تعذر تحميل الطلبات' }); }
});

app.patch('/api/orders/:id', adminGuard, async (req, res) => {
  const allowed = ['new','confirmed','preparing','shipped','completed','cancelled'];
  if (!allowed.includes(req.body.status)) return res.status(400).json({ error: 'حالة غير صالحة' });
  try {
    await pool.query('UPDATE orders SET status=$1 WHERE id=$2', [req.body.status, Number(req.params.id)]);
    res.json({ ok: true });
  } catch (e) { res.status(500).json({ error: 'تعذر تحديث الطلب' }); }
});

initDb().then(() => {
  app.listen(PORT, () => console.log(`معرض أبو ياسر للتبريد يعمل على المنفذ ${PORT}`));
}).catch(err => {
  console.error('Database initialization failed:', err);
  process.exit(1);
});
