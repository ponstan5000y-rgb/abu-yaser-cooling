const DEFAULTS = [
  ['مكيف سبليت 1 طن','مكيفات',650000,5,'❄️',''],
  ['مكيف سبليت 1.5 طن','مكيفات',850000,5,'❄️',''],
  ['مكيف سبليت 2 طن','مكيفات',1100000,3,'❄️',''],
  ['ثلاجة منزلية','ثلاجات',900000,4,'🧊',''],
  ['فريزر أفقي','فريزرات',700000,4,'🧊',''],
  ['قطع غيار تبريد','قطع غيار',25000,20,'🔧','']
];
function json(data,status=200){return new Response(JSON.stringify(data),{status,headers:{'content-type':'application/json; charset=utf-8','cache-control':'no-store'}})}
function adminOk(request,env){return !!env.ADMIN_PASSWORD && (request.headers.get('x-admin-password')||'')===env.ADMIN_PASSWORD}
async function seed(db){const r=await db.prepare('SELECT COUNT(*) c FROM products').first();if(Number(r?.c||0)===0){const s=db.prepare('INSERT INTO products (name,category,price,stock,icon,image) VALUES (?,?,?,?,?,?)');for(const p of DEFAULTS) await s.bind(...p).run();}}
export default {async fetch(request,env){
 const url=new URL(request.url);
 if(url.pathname.startsWith('/api/')){
  try{await seed(env.DB);}catch(e){return json({error:'Database not initialized',detail:String(e)},500)}
  if(url.pathname==='/api/products'&&request.method==='GET'){
   const {results}=await env.DB.prepare('SELECT id,name,category,price,stock,icon,image FROM products ORDER BY id DESC').all();return json(results||[])
  }
  if(url.pathname==='/api/admin/check'&&request.method==='POST') return adminOk(request,env)?json({ok:true}):json({ok:false},401)
  if(url.pathname==='/api/products'&&request.method==='POST'){
   if(!adminOk(request,env))return json({error:'Unauthorized'},401);const p=await request.json();
   if(!p.name||!p.category||!Number.isFinite(Number(p.price)))return json({error:'Missing fields'},400);
   const r=await env.DB.prepare('INSERT INTO products (name,category,price,stock,icon,image) VALUES (?,?,?,?,?,?)').bind(String(p.name),String(p.category),Number(p.price),Math.max(0,Number(p.stock||0)),String(p.icon||'❄️'),String(p.image||'')).run();return json({id:r.meta.last_row_id})
  }
  if(url.pathname.startsWith('/api/products/')&&request.method==='PUT'){
   if(!adminOk(request,env))return json({error:'Unauthorized'},401);const id=Number(url.pathname.split('/').pop());const p=await request.json();
   await env.DB.prepare('UPDATE products SET name=?,category=?,price=?,stock=?,icon=?,image=? WHERE id=?').bind(String(p.name),String(p.category),Number(p.price),Math.max(0,Number(p.stock||0)),String(p.icon||'❄️'),String(p.image||''),id).run();return json({ok:true})
  }
  if(url.pathname.startsWith('/api/products/')&&request.method==='DELETE'){
   if(!adminOk(request,env))return json({error:'Unauthorized'},401);const id=Number(url.pathname.split('/').pop());await env.DB.prepare('DELETE FROM products WHERE id=?').bind(id).run();return json({ok:true})
  }
  return json({error:'Not found'},404)
 }
 return env.ASSETS.fetch(request);
}}
