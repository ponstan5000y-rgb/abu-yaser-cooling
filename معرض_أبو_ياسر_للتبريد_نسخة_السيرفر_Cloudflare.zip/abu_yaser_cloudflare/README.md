# معرض أبو ياسر للتبريد — Cloudflare Workers + D1

## نشر المشروع
1. أنشئ D1 باسم `abu-yaser-db`.
2. نفّذ `schema.sql` على قاعدة D1.
3. ضع `database_id` في `wrangler.toml`.
4. عيّن سر الإدارة:
   `npx wrangler secret put ADMIN_PASSWORD`
5. ثبّت Wrangler ثم نفّذ:
   `npx wrangler deploy`

الموقع سيستخدم D1 لحفظ المنتجات والصور، وليس localStorage.
